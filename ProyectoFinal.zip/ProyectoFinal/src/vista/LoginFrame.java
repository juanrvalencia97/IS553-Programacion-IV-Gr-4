/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.LoginController;
import modelo.Usuario;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.*;

/**
 * Ventana de inicio de sesión.
 * Permite a los usuarios ingresar sus credenciales para iniciar sesión.
 */
public class LoginFrame extends JFrame {

    // Atributos de la interfaz de usuario
    private JTextField correoField;
    private JPasswordField contrasenaField;
    private JButton iniciarSesionButton;
    private JButton registrarseButton;
    private JLabel titleLabel;

    // Controlador de inicio de sesión
    private LoginController loginController;

    /**
     * Constructor de la ventana de inicio de sesión.
     * @param usuariosRegistrados La lista de usuarios registrados.
     */
    public LoginFrame(ArrayList<Usuario> usuariosRegistrados) {
        setTitle("Inicio de Sesión");
        setSize(500, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicialización del controlador
        loginController = new LoginController(usuariosRegistrados);

        // Creación del panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        //Crear el título
        titleLabel = new JLabel("Bienvenido a MyHotel: Inicio de Sesión");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Cambiar el tamaño y el estilo de la fuente
        panel.add(titleLabel);
        
        // Componentes de la interfaz
        JLabel correoLabel = new JLabel("Correo Electrónico:");
        correoField = new JTextField();
        panel.add(correoLabel);
        panel.add(correoField);

        JLabel contrasenaLabel = new JLabel("Contraseña:");
        contrasenaField = new JPasswordField();
        panel.add(contrasenaLabel);
        panel.add(contrasenaField);

        iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String correo = correoField.getText();
                String contrasena = new String(contrasenaField.getPassword());

                //Verificar si los campos están vacíos
                if(correo.isEmpty() || contrasena.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Por favor, rellene todos los campos");
                }
                else{
                // Autenticar al usuario
                boolean autenticado = loginController.autenticarUsuario(correo, contrasena);

                if (autenticado) {
                    // Si el usuario está autenticado, determinar si es administrador o cliente
                    if (correo.equals("juanrojas@myhotel.com") && contrasena.equals("1234")) {
                        // Abrir ventana de acciones del administrador
                        dispose(); // Cerrar la ventana de inicio de sesión
                        new AccionesAdministradorFrame(usuariosRegistrados).setVisible(true);
                    } else {
                        // Abrir ventana de acciones del cliente
                        dispose(); // Cerrar la ventana de inicio de sesión
                        new AccionesClienteFrame(usuariosRegistrados).setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Credenciales incorrectas. Inténtalo de nuevo.");
                }
            }
            }
        });
        panel.add(iniciarSesionButton);

        registrarseButton = new JButton("Registrarse");
        registrarseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abrir ventana de registro
                dispose(); // Cerrar la ventana de inicio de sesión
                new RegistroFrame(usuariosRegistrados).setVisible(true);
            }
        });
        panel.add(registrarseButton);

        // Agregar el panel a la ventana principal
        add(panel);
        setVisible(true);
    }
}

