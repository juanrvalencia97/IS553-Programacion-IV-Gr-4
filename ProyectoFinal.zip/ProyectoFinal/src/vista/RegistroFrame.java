/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.RegistroController;
import modelo.Usuario;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.*;

/**
 * Ventana de registro.
 * Proporciona una interfaz para que los usuarios se registren en el sistema.
 */
public class RegistroFrame extends JFrame {

    private JTextField tipoIdentificacionField;
    private JTextField numeroIdentificacionField;
    private JTextField nombreField;
    private JTextField apellidoField;
    private JTextField correoField;
    private JTextField direccionField;
    private JTextField ciudadField;
    private JTextField telefonoField;
    private JPasswordField contrasenaField;
    private JPasswordField confirmarContrasenaField;
    private JButton registrarButton;
    private JLabel titleLabel;

    private RegistroController registroController;

    /**
     * Constructor de la ventana de registro.
     * @param usuariosRegistrados La lista de usuarios registrados.
     */
    public RegistroFrame(ArrayList<Usuario> usuariosRegistrados) {
        setTitle("Registro");
        setSize(300, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        registroController = new RegistroController();

        //Creación del panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Crear el título
        titleLabel = new JLabel("Formulario de registro");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Cambiar el tamaño y el estilo de la fuente
        panel.add(titleLabel);
        
        JLabel tipoIdentificacionLabel = new JLabel("Tipo de Identificación:");
        tipoIdentificacionField = new JTextField();
        panel.add(tipoIdentificacionLabel);
        panel.add(tipoIdentificacionField);

        JLabel numeroIdentificacionLabel = new JLabel("Número de Identificación:");
        numeroIdentificacionField = new JTextField();
        panel.add(numeroIdentificacionLabel);
        panel.add(numeroIdentificacionField);

        JLabel nombreLabel = new JLabel("Nombre:");
        nombreField = new JTextField();
        panel.add(nombreLabel);
        panel.add(nombreField);

        JLabel apellidoLabel = new JLabel("Apellido:");
        apellidoField = new JTextField();
        panel.add(apellidoLabel);
        panel.add(apellidoField);

        JLabel correoLabel = new JLabel("Correo Electrónico:");
        correoField = new JTextField();
        panel.add(correoLabel);
        panel.add(correoField);

        JLabel direccionLabel = new JLabel("Dirección:");
        direccionField = new JTextField();
        panel.add(direccionLabel);
        panel.add(direccionField);

        JLabel ciudadLabel = new JLabel("Ciudad:");
        ciudadField = new JTextField();
        panel.add(ciudadLabel);
        panel.add(ciudadField);

        JLabel telefonoLabel = new JLabel("Teléfono:");
        telefonoField = new JTextField();
        panel.add(telefonoLabel);
        panel.add(telefonoField);

        JLabel contrasenaLabel = new JLabel("Contraseña:");
        contrasenaField = new JPasswordField();
        panel.add(contrasenaLabel);
        panel.add(contrasenaField);

        JLabel confirmarContrasenaLabel = new JLabel("Confirmar Contraseña:");
        confirmarContrasenaField = new JPasswordField();
        panel.add(confirmarContrasenaLabel);
        panel.add(confirmarContrasenaField);

        registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipoIdentificacion = tipoIdentificacionField.getText();
                String numeroIdentificacion = numeroIdentificacionField.getText();
                String nombre = nombreField.getText();
                String apellido = apellidoField.getText();
                String correo = correoField.getText();
                String direccion = direccionField.getText();
                String ciudad = ciudadField.getText();
                String telefono = telefonoField.getText();
                String contrasena = new String(contrasenaField.getPassword());
                String confirmarContrasena = new String(confirmarContrasenaField.getPassword());

                if (!contrasena.equals(confirmarContrasena)) {
                    JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden.");
                    return;
                }

                Usuario usuario = new Usuario(tipoIdentificacion, numeroIdentificacion, nombre, apellido,
                        correo, direccion, ciudad, telefono, contrasena);

                if (registroController.registrarUsuario(usuario)) {
                    JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente");
                    
                    dispose(); // Cerrar la ventana de registro después de registrar al usuario
                    new LoginFrame(usuariosRegistrados).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar usuario");
                }
            }
        });
        panel.add(registrarButton);

        add(panel);
        setVisible(true);
    }
}

