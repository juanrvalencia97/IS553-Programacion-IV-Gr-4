/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import modelo.Usuario;

/**
 * Ventana de acciones del administrador.
 * Proporciona una interfaz para que los administradores realicen diversas acciones.
 */
public class AccionesAdministradorFrame extends JFrame {

    /**
     * Constructor de la ventana de acciones del administrador.
     * @param usuariosRegistrados La lista de usuarios registrados.
     */
    public AccionesAdministradorFrame(ArrayList<Usuario> usuariosRegistrados) {
        setTitle("Acciones del Administrador");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1));
        panel.setBackground(Color.BLUE); // Color de fondo del panel
        
        
        // Crear botones para cada acción
        String[] acciones = {"Verificar Disponibilidad de Habitaciones", "Agregar Nueva Habitación al Inventario", "Editar Habitación del Inventario", "Eliminar Habitación del Inventario", "Agregar Nuevo Administrador", "Salir"};
        for (String accion : acciones) {
            JButton button = new JButton(accion);
            button.setFont(new Font("Arial", Font.BOLD, 14)); // Cambiar el tipo de letra del botón
            button.setPreferredSize(new Dimension(200, 50)); // Cambiar el tamaño del botón
            button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Agregar espacio alrededor del botón

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (accion.equals("Salir")) {
                        dispose(); // Cerrar la ventana de acciones del administrador
                        // Abrir la ventana de inicio de sesión nuevamente
                        new LoginFrame(usuariosRegistrados).setVisible(true);
                    } else {
                        // Abrir una nueva ventana para la acción seleccionada
                        JFrame actionFrame = new JFrame(accion);
                        actionFrame.setSize(300, 200);
                        actionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        actionFrame.setLocationRelativeTo(null);
                        actionFrame.setVisible(true);
                    }
                }
            });

            panel.add(button);
        }

        add(panel);
        setVisible(true);
    }
}

