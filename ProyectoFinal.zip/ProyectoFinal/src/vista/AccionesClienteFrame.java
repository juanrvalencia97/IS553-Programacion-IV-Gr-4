/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import modelo.Usuario;

/**
 * Ventana de acciones del cliente.
 * Proporciona una interfaz para que los clientes realicen diversas acciones.
 */
public class AccionesClienteFrame extends JFrame {

    /**
     * Constructor de la ventana de acciones del cliente.
     * @param usuariosRegistrados La lista de usuarios registrados.
     */
    public AccionesClienteFrame(ArrayList<Usuario> usuariosRegistrados) {
        setTitle("Acciones del Cliente");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 1));
        panel.setBackground(Color.BLUE);

        // Crear botones para cada acción
        String[] acciones = {"Buscar habitaciones disponibles", "Ver detalles de habitación", "Realizar una reserva", "Modificar reserva", "Cancelar reserva", "Historial de reservas", "Salir"};
        for (String accion : acciones) {
            JButton button = new JButton(accion);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (accion.equals("Salir")) {
                        dispose(); // Cerrar la ventana de acciones del cliente
                        // Abrir la ventana de inicio de sesión nuevamente
                        new LoginFrame(usuariosRegistrados).setVisible(true);
                    } else {
                        switch(accion){
                            case "Buscar habitaciones disponibles":
                                new BuscarHabitacionesFrame();
                                break;
                            case "Ver detalles de habitación":
                                new DetallesHabitacionFrame();
                                break;
                            case "Realizar una reserva":
                                new RealizarReservaFrame();
                                break;
                            case "Modificar reserva":
                                new ModificarReservaFrame();
                                break;
                            case "Cancelar reserva":
                                new CancelarReservaFrame();
                                break;
                            case "Historial de reservas":
                                new HistorialReservasFrame();
                                break;
                                
                        }
                    }
                }
            });
            panel.add(button);
        }

        add(panel);
        setVisible(true);
    }
}
