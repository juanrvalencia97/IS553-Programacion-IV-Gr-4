/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectofinal;

import vista.LoginFrame;
import modelo.Usuario;
import controlador.RegistroController;
import java.util.ArrayList;

/**
 * Clase principal del proyecto.
 * Crea un controlador de registro y una ventana de inicio de sesión.
 */
public class ProyectoFinal {

    /**
     * Método principal del proyecto.
     * Crea un controlador de registro y una ventana de inicio de sesión.
     * @param args Argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        // Crear el controlador de registro
        RegistroController registroController = new RegistroController();

        // Obtener la lista de usuarios registrados desde el controlador de registro
        ArrayList<Usuario> usuariosRegistrados = registroController.obtenerUsuariosRegistrados();

        // Crear la ventana de inicio de sesión, pasando la lista de usuarios
        LoginFrame loginFrame = new LoginFrame(usuariosRegistrados);
        loginFrame.setVisible(true);
    }
    
}
