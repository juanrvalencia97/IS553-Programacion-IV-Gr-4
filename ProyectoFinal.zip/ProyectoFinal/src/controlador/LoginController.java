/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Usuario;
import java.util.ArrayList;

/**
 * Controlador para la autenticación de usuarios.
 * Verifica las credenciales de los usuarios contra una lista de usuarios registrados.
 */
public class LoginController {

    private ArrayList<Usuario> usuariosRegistrados;

    /**
     * Constructor del controlador de inicio de sesión.
     * @param usuariosRegistrados La lista de usuarios registrados.
     */
    public LoginController(ArrayList<Usuario> usuariosRegistrados) {
        this.usuariosRegistrados = usuariosRegistrados;
    }

    /**
     * Autentica a un usuario.
     * @param correo El correo del usuario.
     * @param contrasena La contraseña del usuario.
     * @return true si las credenciales son válidas, false en caso contrario.
     */
    public boolean autenticarUsuario(String correo, String contrasena) {
        // Verificar si las credenciales coinciden con algún usuario registrado
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getCorreo().equals(correo) && usuario.getContrasena().equals(contrasena)) {
                return true; // Credenciales válidas
            }
        }
        return false; // Credenciales inválidas
    }
}


