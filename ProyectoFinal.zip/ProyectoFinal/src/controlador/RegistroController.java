/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Usuario;
import java.util.ArrayList;

/**
 * Controlador para el registro de usuarios.
 * Mantiene una lista de usuarios registrados.
 */
public class RegistroController {

    private static ArrayList<Usuario> usuariosRegistrados = new ArrayList<>();

    /**
     * Constructor del controlador de registro.
     * Inicializa la lista de usuarios registrados y agrega un usuario administrador predefinido.
     */
    public RegistroController() {
        if (usuariosRegistrados.isEmpty()) {
            // Agregar el usuario administrador predefinido
            usuariosRegistrados.add(new Usuario("cedula", "1088826110", "Juan", "Rojas",
                    "juanrojas@myhotel.com", "Pereira", "Pereira", "3045968053", "1234"));
        }
    }

    /**
     * Registra un nuevo usuario.
     * @param usuario El usuario a registrar.
     * @return true si el usuario se registró con éxito, false si el usuario ya estaba registrado.
     */
    public boolean registrarUsuario(Usuario usuario) {
        // Verificar si el usuario ya está registrado
        for (Usuario u : usuariosRegistrados) {
            if (u.getCorreo().equals(usuario.getCorreo())) {
                // Si el correo ya está registrado, no se puede registrar nuevamente
                return false;
            }
        }
        // Si el usuario no está registrado, agregarlo a la lista
        usuariosRegistrados.add(usuario);
        return true;
    }
    
    /**
     * Obtiene la lista de usuarios registrados.
     * @return La lista de usuarios registrados.
     */
    public ArrayList<Usuario> obtenerUsuariosRegistrados(){
        return usuariosRegistrados;
    }
}

